import { Card, Row, Col, Space, Typography, Tooltip, Button } from "antd";
import { SearchOutlined, DeleteFilled } from "@ant-design/icons";
import dayjs from "dayjs";

export const SearchHistoryListItem = (props) => {
  const { style, key, item, onSearch, onDelete } = props;
  return (
    <Card style={style} key={key} bodyStyle={{ padding: 12 }}>
      <Row justify="space-between" align="middle">
        <Col>{item?.location}</Col>
        <Col>
          <Space>
            <Typography.Text>
              {dayjs(item?.timezone).format("YYYY-MM-DD HH:mm a")}
            </Typography.Text>
            <Tooltip title="Search">
              <Button
                icon={<SearchOutlined />}
                className="listing-button"
                shape="circle"
                onClick={() => onSearch(item?.id)}
              ></Button>
            </Tooltip>

            <Tooltip title="Delete">
              <Button
                type="default"
                icon={<DeleteFilled />}
                className="listing-button"
                shape="circle"
                onClick={() => onDelete(item?.id)}
              ></Button>
            </Tooltip>
          </Space>
        </Col>
      </Row>
    </Card>
  );
};
