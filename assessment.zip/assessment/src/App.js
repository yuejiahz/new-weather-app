//external imports
import { useEffect, useState } from "react";
import { Input, Button, Row, Col, Form, Card, Tooltip, Image } from "antd";
import { SearchOutlined, CloseOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { capitalize } from "lodash";

//internal imports
import "./App.css";
import { SearchHistoryListItem } from "./components/searchHistoryListItem";

function App() {
  const [searchHistory, setSearchHistory] = useState([]);
  const [currentSearchResult, setCurrentSearchResult] = useState({});
  const [error, setError] = useState(null);
  const [saveHistory, setSaveHistory] = useState(false);
  const [form] = Form.useForm();

  const antdCardStyle = {
    background: " rgba(255, 255, 255, 0.25)",
    border: "transparent",
  };

  const handlers = {
    getData: async (search) => {
      const { city, country } = search;
      const query = city + "," + country;
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${query}&appid=${process.env.REACT_APP_API_KEY}&units=metric`,
        { type: "cors" }
      );
      if (response.ok) {
        response.json().then(function (response) {
          const { timezone, name, sys, main, weather, wind } = response;
          const { country } = sys;

          const res = {
            location: name + ", " + country,
            temperature: main.temp,
            maxTemp: main.temp_max,
            minTemp: main.temp_min,
            humidity: main.humidity,
            main: weather[0].main,
            currentTime: handlers.getCityCurrentTime(timezone),
            windSpeed: wind.speed,
            description: weather[0].description,
            id: Math.floor(Math.random() * 100000),
          };
          if (saveHistory) {
            setSearchHistory(searchHistory.concat(res));
          }
          setCurrentSearchResult(res);
          setError(false);
        });
      } else if (response.status === 404) {
        setError("Not Found");
      } else if (response.status === 400) {
        setError("Invalid search");
      }
    },
    onSearch: (id) => {
      const searchedItem = searchHistory.find((item) => item?.id === id);
      const searchFilter = searchedItem.location.includes(",")
        ? {
            city: searchedItem?.location.split(",")[0],
            country: searchedItem?.location.split(",")[1],
          }
        : searchedItem.location;
      form.setFieldsValue(searchFilter);
      handlers.getData(searchFilter);
    },
    onDelete: (id) => {
      setSearchHistory(searchHistory.filter((item) => item.id !== id));
    },
    getCityCurrentTime: (timezone) => {
      let cityTime = new Date().getUTCHours() + timezone / 3600;
      if (cityTime >= 24) {
        return cityTime - 24;
      } else if (cityTime < 0) {
        return 24 - cityTime;
      } else {
        return cityTime;
      }
    },
  };
  useEffect(() => {
    handlers.getData({ city: "london" });
    setSaveHistory(true);
  }, []);

  return (
    <div className="App background">
      <Row justify="center" style={{ paddingTop: "25px" }}>
        <Col xs={22} sm={22} md={20} lg={16} xl={16} xxl={16}>
          <Row>
            <Col span={24}>
              <Form form={form} onFinish={handlers.getData}>
                <Row gutter={[8, 0]} justify="space-around">
                  <Col flex="auto">
                    <Form.Item name="city">
                      <Input
                        size="large"
                        style={{ borderRadius: "10px", border: "transparent" }}
                        placeholder="City"
                      />
                    </Form.Item>
                  </Col>
                  <Col flex="auto">
                    <Form.Item name="country">
                      <Input
                        size="large"
                        style={{ borderRadius: "10px", border: "transparent" }}
                        placeholder="Country Code"
                      />
                    </Form.Item>
                  </Col>
                  <Col span="none">
                    <Tooltip title="Search">
                      <Form.Item>
                        <Button
                          htmlType="submit"
                          icon={<SearchOutlined />}
                          className="light-theme-bg txt-white search-button"
                          size="large"
                        ></Button>
                      </Form.Item>
                    </Tooltip>
                  </Col>
                  <Col span="none">
                    <Tooltip title="Clear">
                      <Form.Item>
                        <Button
                          icon={<CloseOutlined />}
                          className="light-theme-bg txt-white search-button"
                          size="large"
                          onClick={() => form.resetFields()}
                        ></Button>
                      </Form.Item>
                    </Tooltip>
                  </Col>
                </Row>
              </Form>
            </Col>
            {error && (
              <Col span={24} className="error">
                {error}
              </Col>
            )}
            <Col span={24}>
              <Card
                style={{
                  ...antdCardStyle,
                  position: "relative",
                  top: "6em",
                  borderRadius: "50px",
                }}
              >
                <Row justify="center" gutter={[0, 16]}>
                  <Col xs={24} sm={24} md={22} lg={22} xl={22} xxl={22}>
                    <Row>
                      <Col xs={10} sm={10} md={12} lg={12} xl={12} xxl={12}>
                        <Row justify="start">
                          <Col>
                            <br />
                            <span>Today's Weather</span>
                          </Col>
                          <Col span={24}>
                            <span className="light-theme-color dashboard">
                              {currentSearchResult?.main}
                            </span>
                          </Col>
                          <Col span={24}>
                            <span>
                              T: {currentSearchResult?.minTemp} &#8451;~
                              {currentSearchResult?.maxTemp}&#8451;
                            </span>
                          </Col>

                          <Col>
                            <span>
                              H:{(currentSearchResult?.humidity || "") + "%"}{" "}
                              &nbsp; L:
                              {(currentSearchResult?.windSpeed || "") + "m/s"}
                            </span>
                          </Col>
                        </Row>
                      </Col>
                      <Col xs={13} sm={13} md={9} lg={9} xl={9} xxl={9}>
                        <Row>
                          <Col span={24}>
                            <Image
                              src="sun.png"
                              preview={false}
                              style={{
                                width: "100%",
                                position: "relative",
                                bottom: "7em",
                                left: "4em",
                              }}
                            />

                            <Row
                              style={{
                                position: "absolute",
                                top: "9em",
                              }}
                              flex="end"
                            >
                              <Col
                                xs={24}
                                sm={24}
                                md={0}
                                lg={0}
                                xl={0}
                                xxl={0}
                                className="txt-gray"
                                style={{ textAlign: "right" }}
                              >
                                {capitalize(currentSearchResult?.description)}
                              </Col>
                              <Col
                                xs={24}
                                sm={24}
                                md={0}
                                lg={0}
                                xl={0}
                                xxl={0}
                                className="txt-gray"
                                style={{ textAlign: "right" }}
                              >
                                Humidity:{currentSearchResult?.humidity} %
                              </Col>
                              <Col
                                xs={24}
                                sm={24}
                                md={0}
                                lg={0}
                                xl={0}
                                xxl={0}
                                className="txt-gray"
                                style={{ textAlign: "right" }}
                              >
                                {dayjs(currentSearchResult?.timezone).format(
                                  "YYYY-MM-DD HH:mm a"
                                )}
                              </Col>
                            </Row>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                    <Row>
                      <Col xs={0} sm={0} md={22} lg={22} xl={22} xxl={22}>
                        <Row justify="space-between">
                          <Col flex="none" className="txt-dark-gray">
                            {currentSearchResult?.location}
                          </Col>
                          <Col flex="none" className="txt-gray">
                            {dayjs(currentSearchResult?.timezone).format(
                              "YYYY-MM-DD HH:mm a"
                            )}
                          </Col>
                          <Col flex="none" className="txt-gray">
                            Humidity:{currentSearchResult?.humidity} %
                          </Col>
                          <Col flex="none" className="txt-gray">
                            {capitalize(currentSearchResult?.description)}
                          </Col>
                        </Row>
                      </Col>
                      <Col xs={24} sm={24} md={0} lg={0} xl={0} xxl={0}>
                        <Row gutter={[8, 0]} justify="space-between">
                          <Col flex="none" className="txt-dark-gray">
                            {currentSearchResult?.location}
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                  </Col>

                  <Col
                    xs={24}
                    sm={24}
                    md={22}
                    lg={22}
                    xl={22}
                    xxl={22}
                    style={{ position: "relative" }}
                  >
                    <Card
                      style={{
                        ...antdCardStyle,
                        borderRadius: "20px",
                      }}
                    >
                      <p className="txt-left">Search History</p>
                      <Row gutter={[0, 8]}>
                        {searchHistory?.map((item, index) => (
                          <Col span={24}>
                            <SearchHistoryListItem
                              item={item}
                              style={{ ...antdCardStyle, borderRadius: "20px" }}
                              key={item?.id}
                              onDelete={handlers.onDelete}
                              onSearch={handlers.onSearch}
                            />
                          </Col>
                        ))}
                      </Row>
                    </Card>
                  </Col>
                </Row>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </div>
  );
}

export default App;
